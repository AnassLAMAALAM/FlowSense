// Generates flows.json from the function sources in ./functions
// Usage: node build-flows.js   (re-run after editing any function file)
const fs = require('fs');
const path = require('path');

const fn = name => fs.readFileSync(path.join(__dirname, 'functions', name + '.js'), 'utf8');
const TAB = 'tab_traffic';
const BROKER = 'broker_mosquitto';

const nodes = [
  { id: TAB, type: 'tab', label: 'Smart Traffic Processing', disabled: false,
    info: 'MQTT ingestion → validation → processing & congestion detection → signal optimization → emergency pre-emption → backend routing' },
  { id: BROKER, type: 'mqtt-broker', name: 'Mosquitto', broker: '${MQTT_HOST}', port: '1883',
    clientid: 'node-red-traffic', autoConnect: true, usetls: false, protocolVersion: '4', keepalive: '60',
    cleansession: true, birthTopic: 'traffic/status/node-red', birthQos: '0', birthRetain: 'true', birthPayload: '{"online":true}',
    closeTopic: '', willTopic: 'traffic/status/node-red', willQos: '0', willRetain: 'true', willPayload: '{"online":false}' },

  // comments (section headers in the editor)
  { id: 'c1', type: 'comment', z: TAB, name: '1. MQTT ingestion & validation', x: 170, y: 40, wires: [] },
  { id: 'c2', type: 'comment', z: TAB, name: '2. Processing, congestion, signals, emergency', x: 230, y: 180, wires: [] },
  { id: 'c3', type: 'comment', z: TAB, name: '3. Manual signal control (from dashboard)', x: 210, y: 400, wires: [] },

  { id: 'mqtt_in_sensors', type: 'mqtt in', z: TAB, name: 'traffic/sensors/+', topic: 'traffic/sensors/+', qos: '0',
    datatype: 'json', broker: BROKER, nl: false, rap: true, rh: 0, inputs: 0, x: 140, y: 100, wires: [['fn_validate']] },
  { id: 'fn_validate', type: 'function', z: TAB, name: 'Data validation', func: fn('validate'), outputs: 2,
    noerr: 0, x: 360, y: 100, wires: [['fn_process'], ['dbg_rejected']] },
  { id: 'dbg_rejected', type: 'debug', z: TAB, name: 'Rejected readings', active: true, tosidebar: true,
    console: true, complete: 'payload', statusVal: 'payload.reason', statusType: 'msg', x: 590, y: 120, wires: [] },

  { id: 'fn_process', type: 'function', z: TAB, name: 'Processing + congestion detection', func: fn('process'), outputs: 1,
    x: 210, y: 240, wires: [['fn_signal']] },
  { id: 'fn_signal', type: 'function', z: TAB, name: 'Signal optimization (Webster)', func: fn('signal'), outputs: 1,
    x: 500, y: 240, wires: [['fn_emergency']] },
  { id: 'fn_emergency', type: 'function', z: TAB, name: 'Emergency detection', func: fn('emergency'), outputs: 2,
    x: 230, y: 320, wires: [['fn_route'], ['mqtt_out_signals']] },
  { id: 'fn_route', type: 'function', z: TAB, name: 'Backend routing', func: fn('route'), outputs: 1,
    x: 460, y: 300, wires: [['http_backend']] },
  { id: 'http_backend', type: 'http request', z: TAB, name: 'POST /api/ingest', method: 'use', ret: 'obj',
    paytoqs: 'ignore', url: '', tls: '', persist: true, proxy: '', insecureHTTPParser: false, authType: '',
    senderr: false, headers: [], x: 670, y: 300, wires: [['fn_http_status']] },
  { id: 'fn_http_status', type: 'function', z: TAB, name: 'Check backend response',
    func: "if (msg.statusCode >= 300 || msg.statusCode === undefined) {\n  node.status({fill:'red',shape:'ring',text:'backend ' + (msg.statusCode || 'unreachable')});\n  node.warn('Backend rejected ingest: ' + msg.statusCode);\n} else {\n  node.status({fill:'green',shape:'dot',text:'backend ok'});\n}\nreturn null;",
    outputs: 1, x: 880, y: 300, wires: [[]] },
  { id: 'mqtt_out_signals', type: 'mqtt out', z: TAB, name: 'traffic/signals/<id>', topic: '', qos: '', retain: '',
    broker: BROKER, x: 480, y: 350, wires: [] },

  { id: 'mqtt_in_control', type: 'mqtt in', z: TAB, name: 'traffic/control/+', topic: 'traffic/control/+', qos: '1',
    datatype: 'json', broker: BROKER, nl: false, rap: true, rh: 0, inputs: 0, x: 140, y: 460, wires: [['fn_control']] },
  { id: 'fn_control', type: 'function', z: TAB, name: 'Apply manual override', func: fn('control'), outputs: 1,
    x: 380, y: 460, wires: [[]] },

  { id: 'catch_all', type: 'catch', z: TAB, name: 'Errors', scope: null, uncaught: false, x: 120, y: 540, wires: [['dbg_errors']] },
  { id: 'dbg_errors', type: 'debug', z: TAB, name: 'Flow errors', active: true, tosidebar: true, console: true,
    complete: 'error', x: 300, y: 540, wires: [] }
];

fs.writeFileSync(path.join(__dirname, 'flows.json'), JSON.stringify(nodes, null, 2));
console.log(`flows.json written (${nodes.length} nodes)`);
