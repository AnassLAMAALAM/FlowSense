import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip, Polyline, useMap } from 'react-leaflet';
import { LevelBadge, ModeBadge } from '../components/common';
import { LEVELS, LEVEL_ORDER, STATUS_HEX, fmt } from '../theme';

const colorOf = (level) => STATUS_HEX[LEVELS[level]?.role] || '#898781';

function FlyTo({ target }) {
  const map = useMap();
  useEffect(() => {
    if (target) map.flyTo([target.lat, target.lng], 17, { duration: 0.6 });
  }, [target, map]);
  return null;
}

/** Road segments between neighbouring intersections, coloured by the worse end. */
function roadSegments(list) {
  const pts = list.filter((i) => i.location);
  const segs = [];
  for (let a = 0; a < pts.length; a++) {
    for (let b = a + 1; b < pts.length; b++) {
      const A = pts[a].location, B = pts[b].location;
      const sameRow = Math.abs(A.lat - B.lat) < 1e-4 && Math.abs(A.lng - B.lng) < 0.0065;
      const sameCol = Math.abs(A.lng - B.lng) < 1e-4 && Math.abs(A.lat - B.lat) < 0.006;
      if (sameRow || sameCol) {
        const la = pts[a].latest?.congestionLevel, lb = pts[b].latest?.congestionLevel;
        const worse = LEVEL_ORDER[Math.max(LEVEL_ORDER.indexOf(la), LEVEL_ORDER.indexOf(lb))];
        segs.push({ key: `${pts[a].id}-${pts[b].id}`, positions: [[A.lat, A.lng], [B.lat, B.lng]], level: worse });
      }
    }
  }
  return segs;
}

export default function MapView({ live }) {
  const { list, emergencies } = live;
  const [selected, setSelected] = useState(null);
  const located = list.filter((i) => i.location);
  if (!located.length) return <div className="card empty">Loading map…</div>;
  const center = [
    located.reduce((s, i) => s + i.location.lat, 0) / located.length,
    located.reduce((s, i) => s + i.location.lng, 0) / located.length,
  ];

  return (
    <>
      <div className="section-head">
        <div>
          <h2>Congestion map</h2>
          <p>Marker size grows with queue length · road colour shows the worse of its two intersections</p>
        </div>
        <div className="legend">
          {LEVEL_ORDER.map((l) => (
            <span key={l}><i style={{ background: STATUS_HEX[LEVELS[l].role] }} />{LEVELS[l].icon} {LEVELS[l].label}</span>
          ))}
        </div>
      </div>
      <div className="map-wrap">
        <div className="map">
          <MapContainer center={center} zoom={16} style={{ height: '100%', width: '100%' }} scrollWheelZoom>
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {roadSegments(located).map((s) => (
              <Polyline key={s.key} positions={s.positions} pathOptions={{ color: colorOf(s.level), weight: 7, opacity: 0.75 }} />
            ))}
            {located.map((i) => {
              const ev = emergencies[i.id];
              const q = i.latest?.totalQueue || 0;
              return (
                <CircleMarker
                  key={i.id}
                  center={[i.location.lat, i.location.lng]}
                  radius={10 + Math.min(16, q / 6)}
                  pathOptions={{
                    color: ev ? '#d03b3b' : '#ffffff',
                    weight: ev ? 4 : 2,
                    fillColor: colorOf(i.latest?.congestionLevel),
                    fillOpacity: 0.9,
                  }}
                  eventHandlers={{ click: () => setSelected(i.id) }}
                >
                  <Tooltip direction="top" offset={[0, -8]}>{i.name}</Tooltip>
                  <Popup>
                    <strong>{i.name}</strong> ({i.id})<br />
                    Level: {LEVELS[i.latest?.congestionLevel]?.label || '—'}<br />
                    Flow {fmt.int(i.latest?.flowVph)} veh/h · {fmt.one(i.latest?.avgSpeed)} km/h<br />
                    Queue {fmt.int(q)} veh · occupancy {fmt.one(i.latest?.avgOccupancy)}%<br />
                    Signal: {i.signal?.mode} · NS {i.signal?.nsGreen}s / EW {i.signal?.ewGreen}s
                    {ev && <><br /><b style={{ color: '#d03b3b' }}>Emergency: {ev.type} from {ev.approach}</b></>}
                  </Popup>
                </CircleMarker>
              );
            })}
            <FlyTo target={located.find((i) => i.id === selected)?.location} />
          </MapContainer>
        </div>
        <div className="map-list">
          {located.map((i) => (
            <button key={i.id} className={`map-item ${selected === i.id ? 'sel' : ''}`} onClick={() => setSelected(i.id)}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 6 }}>
                <b>{i.name}</b>
                <LevelBadge level={i.latest?.congestionLevel} />
              </div>
              <span style={{ fontSize: 12, color: 'var(--text-2)' }}>
                {fmt.int(i.latest?.flowVph)} veh/h · {fmt.one(i.latest?.avgSpeed)} km/h · queue {fmt.int(i.latest?.totalQueue)}
              </span>
              <span><ModeBadge mode={i.signal?.mode} /></span>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
