module.exports = {
  port: Number(process.env.PORT || 4000),
  mongoUrl: process.env.MONGO_URL || 'mongodb://localhost:27017/smart_traffic',
  mqttUrl: process.env.MQTT_URL || 'mqtt://localhost:1883',
  ingestToken: process.env.INGEST_TOKEN || 'dev-ingest-token',
  corsOrigin: process.env.CORS_ORIGIN || '*',
  // raw readings older than this are removed automatically (TTL index)
  readingsTtlDays: Number(process.env.READINGS_TTL_DAYS || 30),
};
