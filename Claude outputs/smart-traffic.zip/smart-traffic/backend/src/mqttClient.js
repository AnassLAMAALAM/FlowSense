// MQTT client used by the backend to send manual signal commands to Node-RED
// and to track device online status.
const mqtt = require('mqtt');
const realtime = require('./realtime');

let client = null;
const status = { broker: false, simulator: null, nodeRed: null };

function connect(url) {
  client = mqtt.connect(url, {
    clientId: `traffic-backend-${Math.random().toString(16).slice(2, 8)}`,
    reconnectPeriod: 3000,
  });
  client.on('connect', () => {
    status.broker = true;
    console.log(`[mqtt] connected to ${url}`);
    client.subscribe('traffic/status/+');
    realtime.emit('system:status', getStatus());
  });
  client.on('close', () => {
    if (status.broker) realtime.emit('system:status', { ...getStatus(), broker: false });
    status.broker = false;
  });
  client.on('error', (err) => console.error('[mqtt] error', err.message));
  client.on('message', (topic, buf) => {
    try {
      const msg = JSON.parse(buf.toString());
      if (topic === 'traffic/status/simulator') status.simulator = !!msg.online;
      if (topic === 'traffic/status/node-red') status.nodeRed = !!msg.online;
      realtime.emit('system:status', getStatus());
    } catch {
      /* ignore non-JSON status */
    }
  });
  return client;
}

function publishControl(intersectionId, command) {
  return new Promise((resolve, reject) => {
    if (!client || !client.connected) return reject(new Error('MQTT broker not connected'));
    client.publish(`traffic/control/${intersectionId}`, JSON.stringify(command), { qos: 1, retain: true }, (err) =>
      err ? reject(err) : resolve()
    );
  });
}

function getStatus() {
  return { ...status };
}

module.exports = { connect, publishControl, getStatus };
