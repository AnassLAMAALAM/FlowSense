"""
Virtual Traffic Sensor Generator
================================

Simulates IoT traffic sensors at a set of signalised intersections and publishes
their measurements over MQTT.

Each intersection has four approaches (N, S, E, W). Every interval the simulator:
  * generates vehicle arrivals from a time-of-day demand profile (+ noise and
    random incidents),
  * discharges vehicles according to the green time the signal currently gives
    that approach (so Node-RED's adaptive timings feed back into the traffic),
  * derives vehicle count, average speed, road occupancy and queue length,
  * occasionally injects an emergency vehicle (ambulance / fire / police).

Topics
------
  publish   traffic/sensors/<intersectionId>        sensor reading (JSON)
  subscribe traffic/signals/<intersectionId>        signal plan from Node-RED

Environment variables
---------------------
  MQTT_HOST (localhost)  MQTT_PORT (1883)  INTERVAL_SEC (5)
  SIM_TIME_SCALE (60)    -> simulated seconds per real second for the daily profile
  EMERGENCY_PROB (0.01)  -> chance per intersection per interval
  INCIDENT_PROB (0.004)  -> chance an approach gets a temporary incident
  SEED (unset)           -> fixed random seed for reproducible runs
"""

import json
import math
import os
import random
import signal
import sys
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
INTERVAL_SEC = float(os.getenv("INTERVAL_SEC", "5"))
SIM_TIME_SCALE = float(os.getenv("SIM_TIME_SCALE", "60"))
EMERGENCY_PROB = float(os.getenv("EMERGENCY_PROB", "0.01"))
INCIDENT_PROB = float(os.getenv("INCIDENT_PROB", "0.004"))
if os.getenv("SEED"):
    random.seed(int(os.environ["SEED"]))

APPROACHES = ("N", "S", "E", "W")
SATURATION_FLOW = 1800  # vehicles / hour / lane while green
VEHICLE_LENGTH_M = 6.5  # effective length incl. gap, for occupancy
DETECTION_ZONE_M = 120  # length of road the sensor observes per lane

# Must match database/init.sql seed data
INTERSECTIONS = [
    {"id": "INT-001", "lanes": 2, "free_flow": 50, "base": {"N": 1300, "S": 1200, "E": 950, "W": 1000}},
    {"id": "INT-002", "lanes": 3, "free_flow": 60, "base": {"N": 2300, "S": 2150, "E": 900, "W": 950}},
    {"id": "INT-003", "lanes": 2, "free_flow": 50, "base": {"N": 750, "S": 800, "E": 1450, "W": 1400}},
    {"id": "INT-004", "lanes": 2, "free_flow": 40, "base": {"N": 1050, "S": 1000, "E": 1050, "W": 950}},
    {"id": "INT-005", "lanes": 3, "free_flow": 60, "base": {"N": 1100, "S": 1050, "E": 2350, "W": 2250}},
    {"id": "INT-006", "lanes": 1, "free_flow": 40, "base": {"N": 560, "S": 520, "E": 480, "W": 540}},
]

VEHICLE_TYPES = [("car", 0.78), ("van", 0.1), ("truck", 0.05), ("bus", 0.04), ("motorbike", 0.03)]
EMERGENCY_TYPES = ("ambulance", "fire_truck", "police")


def day_profile(sim_hour: float) -> float:
    """Demand multiplier over the day: morning and evening peaks, quiet night."""
    morning = 0.9 * math.exp(-((sim_hour - 8.25) ** 2) / 1.6)
    evening = 1.0 * math.exp(-((sim_hour - 18.0) ** 2) / 2.2)
    midday = 0.25 * math.exp(-((sim_hour - 13.5) ** 2) / 4.0)
    night_floor = 0.15 + 0.35 * (1 / (1 + math.exp(-(sim_hour - 6.0) * 2))) * (
        1 / (1 + math.exp((sim_hour - 22.5) * 2))
    )
    return night_floor + morning + evening + midday


@dataclass
class Approach:
    name: str
    base_demand: float  # vehicles / hour at multiplier 1
    queue: float = 0.0
    incident_until: float = 0.0  # epoch seconds


@dataclass
class Intersection:
    id: str
    lanes: int
    free_flow: float
    approaches: dict
    # current signal plan (seconds); updated from Node-RED
    cycle: float = 90.0
    ns_green: float = 40.0
    ew_green: float = 40.0
    preempt_approach: str | None = None
    emergency_until: float = 0.0
    emergency: dict | None = None
    seq: int = 0

    def green_ratio(self, approach: str) -> float:
        if self.preempt_approach:
            phase = "NS" if self.preempt_approach in ("N", "S") else "EW"
            mine = "NS" if approach in ("N", "S") else "EW"
            return 0.9 if phase == mine else 0.05
        green = self.ns_green if approach in ("N", "S") else self.ew_green
        return max(0.05, min(0.9, green / max(self.cycle, 1)))


def build_intersections():
    result = {}
    for cfg in INTERSECTIONS:
        result[cfg["id"]] = Intersection(
            id=cfg["id"],
            lanes=cfg["lanes"],
            free_flow=cfg["free_flow"],
            approaches={a: Approach(a, cfg["base"][a]) for a in APPROACHES},
        )
    return result


class Simulator:
    def __init__(self):
        self.intersections = build_intersections()
        self.sim_start_real = time.time()
        now = datetime.now()
        self.sim_start_hour = now.hour + now.minute / 60
        self.running = True
        self.client = mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2, client_id=f"traffic-sim-{uuid.uuid4().hex[:6]}"
        )
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.will_set("traffic/status/simulator", json.dumps({"online": False}), retain=True)

    # ---------- MQTT ----------
    def on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code.is_failure:
            print(f"[sim] MQTT connect failed: {reason_code}", flush=True)
            return
        print(f"[sim] connected to mqtt://{MQTT_HOST}:{MQTT_PORT}", flush=True)
        client.subscribe("traffic/signals/+", qos=1)
        client.publish("traffic/status/simulator", json.dumps({"online": True}), retain=True)

    def on_message(self, client, userdata, msg):
        try:
            plan = json.loads(msg.payload)
            inter = self.intersections.get(plan.get("intersectionId"))
            if not inter:
                return
            inter.cycle = float(plan.get("cycleLength", inter.cycle))
            inter.ns_green = float(plan.get("nsGreen", inter.ns_green))
            inter.ew_green = float(plan.get("ewGreen", inter.ew_green))
            inter.preempt_approach = plan.get("preemptApproach")
        except (ValueError, TypeError) as exc:
            print(f"[sim] bad signal plan on {msg.topic}: {exc}", flush=True)

    # ---------- simulation ----------
    def sim_hour(self) -> float:
        elapsed_real = time.time() - self.sim_start_real
        return (self.sim_start_hour + elapsed_real * SIM_TIME_SCALE / 3600) % 24

    def step_intersection(self, inter: Intersection, now: float, hour: float) -> dict:
        inter.seq += 1
        mult = day_profile(hour)
        # Traffic dynamics run on simulated time: each tick covers a window of
        # INTERVAL_SEC * SIM_TIME_SCALE simulated seconds (5 s * 60 = 5 min).
        window_sec = INTERVAL_SEC * SIM_TIME_SCALE
        dt_h = window_sec / 3600
        detection_capacity = inter.lanes * DETECTION_ZONE_M / VEHICLE_LENGTH_M

        # emergency vehicle lifecycle
        if inter.emergency and now > inter.emergency_until:
            inter.emergency = None
        if not inter.emergency and random.random() < EMERGENCY_PROB:
            inter.emergency = {
                "detected": True,
                "vehicleId": f"EV-{uuid.uuid4().hex[:5].upper()}",
                "type": random.choice(EMERGENCY_TYPES),
                "approach": random.choice(APPROACHES),
                "distanceM": random.randint(150, 400),
            }
            inter.emergency_until = now + random.uniform(15, 30)
        if inter.emergency:
            inter.emergency["distanceM"] = max(0, inter.emergency["distanceM"] - random.randint(40, 90))

        readings = []
        vehicles = []
        for a in inter.approaches.values():
            if a.incident_until < now and random.random() < INCIDENT_PROB:
                a.incident_until = now + random.uniform(60, 180)
            incident = a.incident_until > now

            demand = a.base_demand * mult * random.uniform(0.85, 1.15)
            arrivals = max(0, random.gauss(demand * dt_h, math.sqrt(max(demand * dt_h, 1e-6))))
            capacity = SATURATION_FLOW * inter.lanes * inter.green_ratio(a.name) * dt_h
            if incident:
                capacity *= 0.35
            departures = min(a.queue + arrivals, capacity * random.uniform(0.9, 1.05))
            a.queue = max(0.0, a.queue + arrivals - departures)

            # occupancy = stopped (queued) vehicles + moving vehicles in the zone
            moving_density = (departures * 3600 / window_sec) / inter.lanes / max(inter.free_flow * 0.7, 5)
            occupancy = min(98.0, a.queue / detection_capacity * 100 + moving_density * VEHICLE_LENGTH_M / 10)
            occupancy = max(0.5, occupancy + random.uniform(-2, 2))
            speed_factor = max(0.08, 1 - (occupancy / 100) ** 1.4)
            if incident:
                speed_factor *= 0.5
            avg_speed = max(2.0, inter.free_flow * speed_factor * random.uniform(0.92, 1.05))
            count = int(round(departures))

            readings.append(
                {
                    "approach": a.name,
                    "vehicleCount": count,
                    "avgSpeed": round(avg_speed, 1),
                    "occupancy": round(occupancy, 1),
                    "queueLength": int(round(a.queue)),
                    "incident": incident,
                }
            )

            # individual notable vehicle detections (speeding / heavy vehicles)
            for _ in range(min(count, 3)):
                vtype = random.choices([t for t, _ in VEHICLE_TYPES], [w for _, w in VEHICLE_TYPES])[0]
                vspeed = max(1.0, random.gauss(avg_speed, avg_speed * 0.18))
                if vspeed > inter.free_flow * 1.2 or vtype in ("truck", "bus"):
                    vehicles.append(
                        {
                            "vehicleId": f"V-{uuid.uuid4().hex[:6].upper()}",
                            "type": vtype,
                            "speed": round(vspeed, 1),
                            "approach": a.name,
                            "isEmergency": False,
                        }
                    )

        if inter.emergency:
            vehicles.append(
                {
                    "vehicleId": inter.emergency["vehicleId"],
                    "type": inter.emergency["type"],
                    "speed": round(random.uniform(35, 70), 1),
                    "approach": inter.emergency["approach"],
                    "isEmergency": True,
                }
            )

        return {
            "sensorId": f"SENSOR-{inter.id}",
            "intersectionId": inter.id,
            "seq": inter.seq,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "intervalSec": window_sec,  # measurement window (simulated seconds)
            "lanes": inter.lanes,
            "freeFlowSpeed": inter.free_flow,
            "simHour": round(hour, 2),
            "approaches": readings,
            "vehicles": vehicles,
            "emergency": inter.emergency or {"detected": False},
        }

    def run(self):
        while self.running:
            try:
                self.client.connect(MQTT_HOST, MQTT_PORT, keepalive=30)
                break
            except OSError as exc:
                print(f"[sim] broker not reachable ({exc}); retrying in 3s", flush=True)
                time.sleep(3)
        self.client.loop_start()

        next_tick = time.time()
        while self.running:
            now = time.time()
            hour = self.sim_hour()
            for inter in self.intersections.values():
                payload = self.step_intersection(inter, now, hour)
                self.client.publish(f"traffic/sensors/{inter.id}", json.dumps(payload), qos=0)
            print(
                f"[sim] tick sim-hour={hour:05.2f} profile={day_profile(hour):.2f} "
                f"published={len(self.intersections)}",
                flush=True,
            )
            next_tick += INTERVAL_SEC
            time.sleep(max(0, next_tick - time.time()))

        self.client.publish("traffic/status/simulator", json.dumps({"online": False}), retain=True)
        self.client.loop_stop()
        self.client.disconnect()

    def stop(self, *_):
        self.running = False


if __name__ == "__main__":
    sim = Simulator()
    signal.signal(signal.SIGINT, sim.stop)
    signal.signal(signal.SIGTERM, sim.stop)
    if "--dry-run" in sys.argv:
        # print a few readings without a broker (useful for testing)
        hour = sim.sim_hour()
        for _ in range(3):
            for inter in sim.intersections.values():
                print(json.dumps(sim.step_intersection(inter, time.time(), hour)))
        sys.exit(0)
    sim.run()
